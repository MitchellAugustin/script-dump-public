//! Mostly used for slint/rog type conversions

pub mod aura_types;
pub mod fan_types;
